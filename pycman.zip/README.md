# Pycman Package Development
Package to train and eveluate an AI in ATARI environments in which observations are the pixel values.
The main branch only contains a working version of the code. Take a look [at the wiki](https://github.com/GnomeBlue/pycman/wiki) to find more information about the package and the team.

# Getting started
You can run the unit tests to see if your install has been successful. Run _pycman/main_gui.py_ to load the GUI and get started. The algorithms class is the class to inherit if you want to construct custom algorithms to train and run.

