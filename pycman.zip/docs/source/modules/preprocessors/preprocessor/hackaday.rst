

Hackaday
--------


.. toctree::


.. automodule:: pycman.preprocessors.preprocessor_hackaday
    :inherited-members:
    :special-members: __init__