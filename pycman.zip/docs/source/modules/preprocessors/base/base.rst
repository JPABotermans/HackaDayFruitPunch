
Base
----

.. toctree::

.. automodule:: pycman.preprocessors.base.preprocessor_base
    :inherited-members:
    :special-members: __init__