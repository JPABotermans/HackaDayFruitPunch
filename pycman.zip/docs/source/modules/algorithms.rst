

Algorithm
---------

.. toctree::


.. toctree::
    algorithms/algorithms
    algorithms/base

