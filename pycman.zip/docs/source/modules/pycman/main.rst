

.. toctree::



main gui
========

You can run this code in order to start the gui.
The gui is meant to help you create '.ini' files.
After the creation of these files, it is advisable
to switch to the 'main_load_ini.py'.


main load ini
=============

When you have created or altered a '.ini' file you
can load it directly by adding an absolute path to
it in the path variable. This will prevent you from
having to start the gui every time you want to run it.