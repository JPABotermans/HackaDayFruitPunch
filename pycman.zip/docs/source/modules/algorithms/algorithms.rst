

Algorithms
----------

.. toctree::

    algorithms/human
    algorithms/random
    algorithms/template