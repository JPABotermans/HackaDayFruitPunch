
Template Algorithm
------------------


.. toctree::


.. automodule:: pycman.algorithms.template_algorithm
    :inherited-members:
    :special-members: __init__