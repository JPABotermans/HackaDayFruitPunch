

Human
-----

.. toctree::



.. automodule:: pycman.algorithms.algorithm_human
    :inherited-members:
    :special-members: __init__