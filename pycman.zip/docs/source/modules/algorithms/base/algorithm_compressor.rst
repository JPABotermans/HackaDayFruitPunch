
Algorithm compressor
--------------------

.. toctree::



.. automodule:: pycman.algorithms.base.algorithm_compressor
    :members:
    :undoc-members:
    :special-members: __init__