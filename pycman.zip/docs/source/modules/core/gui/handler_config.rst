

Handler Config
--------------

.. toctree::



.. automodule:: pycman.core.gui.auxiliary.handler_config
    :members:
    :undoc-members:
    :special-members: __init__