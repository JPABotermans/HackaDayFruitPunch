

Constants
---------

.. toctree::


.. automodule:: pycman.core.gui.auxiliary.constants
    :members:
    :undoc-members:
    :special-members: __init__

Easy file for maintaining all constants.