

GUI
---

.. toctree::


.. toctree::
    gui/constants
    gui/handler_players
    gui/handler_config
    gui/handler_game_gui

.. automodule:: pycman.core.gui.start_menu
    :members:
    :undoc-members:
    :special-members: __init__