"""
    Date created: 2019/03/15
    Python Version: 3.7
    License: MIT License

    Take a look at the pycman repository or the MIT license for more information on the use and reuse of pycman.
"""


__all__ = ['constants', 'handler_config', 'handler_game_gui', 'handler_players', 'os_specific']